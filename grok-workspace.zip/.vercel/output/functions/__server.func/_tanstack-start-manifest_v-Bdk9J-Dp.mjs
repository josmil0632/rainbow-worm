//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bdk9J-Dp.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-aGDn5anI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-aGDn5anI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-MVMCgFWN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
