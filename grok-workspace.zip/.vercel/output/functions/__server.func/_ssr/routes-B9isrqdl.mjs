import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, i as Star, n as Volume2, o as Play, s as Pause, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B9isrqdl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NOTES = [
	261.63,
	329.63,
	392,
	523.25,
	392,
	329.63,
	293.66,
	440
];
var Sfx = class {
	ctx = null;
	master = null;
	music = null;
	noise = null;
	nextNote = 0;
	step = 0;
	muted = false;
	musicOn = false;
	unlock() {
		if (typeof window === "undefined") return;
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return;
		if (!this.ctx) {
			this.ctx = new AC({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.master.gain.value = this.muted ? 0 : .42;
			this.music = this.ctx.createGain();
			this.music.gain.value = .22;
			this.music.connect(this.master);
			this.master.connect(this.ctx.destination);
			const n = this.ctx.createBuffer(1, this.ctx.sampleRate * .4, this.ctx.sampleRate);
			const data = n.getChannelData(0);
			for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
			this.noise = n;
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	resume() {
		if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
	}
	setMuted(muted) {
		this.muted = muted;
		if (!this.ctx || !this.master) return;
		this.master.gain.setTargetAtTime(muted ? 0 : .42, this.ctx.currentTime, .02);
	}
	toggleMuted() {
		this.setMuted(!this.muted);
		return this.muted;
	}
	pump() {
		if (!this.ctx || !this.music || !this.musicOn || this.muted) return;
		const t = this.ctx.currentTime;
		if (this.nextNote < t) this.nextNote = t + .02;
		while (this.nextNote < t + .4) {
			this.blip(NOTES[this.step % NOTES.length], this.nextNote, .28, "triangle", .045, this.music);
			this.step++;
			this.nextNote += this.step % 4 === 0 ? .56 : .28;
		}
	}
	jump() {
		if (!this.ctx || !this.master) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		osc.type = "triangle";
		osc.frequency.setValueAtTime(380, t);
		osc.frequency.exponentialRampToValueAtTime(720, t + .09);
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(.22, t + .02);
		g.gain.exponentialRampToValueAtTime(1e-4, t + .16);
		osc.connect(g);
		g.connect(this.master);
		osc.start(t);
		osc.stop(t + .18);
	}
	land() {
		this.noiseBurst(.07, .08, 900);
	}
	star() {
		if (!this.ctx || !this.master) return;
		const t = this.ctx.currentTime;
		this.blip(880, t, .1, "sine", .12, this.master);
		this.blip(1320, t + .06, .14, "sine", .1, this.master);
	}
	near() {
		if (!this.ctx || !this.master) return;
		const t = this.ctx.currentTime;
		this.blip(660, t, .08, "triangle", .1, this.master);
		this.blip(990, t + .05, .12, "triangle", .09, this.master);
	}
	crash() {
		if (!this.ctx || !this.master) return;
		const t = this.ctx.currentTime;
		this.noiseBurst(.35, .28, 500);
		const osc = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(160, t);
		osc.frequency.exponentialRampToValueAtTime(48, t + .32);
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(.16, t + .02);
		g.gain.exponentialRampToValueAtTime(1e-4, t + .36);
		osc.connect(g);
		g.connect(this.master);
		osc.start(t);
		osc.stop(t + .38);
	}
	close() {
		this.ctx?.close();
		this.ctx = null;
		this.master = null;
		this.music = null;
	}
	blip(freq, when, dur, type, gain, dest) {
		if (!this.ctx) return;
		const osc = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, when);
		g.gain.setValueAtTime(1e-4, when);
		g.gain.exponentialRampToValueAtTime(gain, when + .02);
		g.gain.exponentialRampToValueAtTime(1e-4, when + dur);
		osc.connect(g);
		g.connect(dest);
		osc.start(when);
		osc.stop(when + dur + .02);
	}
	noiseBurst(dur, gain, lp) {
		if (!this.ctx || !this.master || !this.noise) return;
		const t = this.ctx.currentTime;
		const src = this.ctx.createBufferSource();
		src.buffer = this.noise;
		const filter = this.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.setValueAtTime(lp, t);
		const g = this.ctx.createGain();
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(gain, t + .015);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		src.connect(filter);
		filter.connect(g);
		g.connect(this.master);
		src.start(t);
		src.stop(t + dur + .02);
	}
};
function hash$1(n) {
	const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
	return x - Math.floor(x);
}
function drawWorld(ctx, g) {
	const { width: w, height: h } = g;
	const sky = ctx.createLinearGradient(0, 0, 0, h);
	sky.addColorStop(0, "#120a22");
	sky.addColorStop(.45, "#0b0716");
	sky.addColorStop(1, "#07060e");
	ctx.fillStyle = sky;
	ctx.fillRect(0, 0, w, h);
	drawNebula(ctx, g);
	drawWormhole(ctx, g);
	drawStars(ctx, g);
	if (g.speed > g.maxSpeed * .72 && g.mode === "play") drawStreaks(ctx, g);
	drawGround(ctx, g);
	for (const o of g.obstacles) if (o.active) drawObstacle(ctx, g, o);
	for (const p of g.pickups) if (p.active) drawStarPickup(ctx, g, p);
	drawParticles(ctx, g);
	drawShadow(ctx, g);
	drawWorm(ctx, g);
	drawFloaters(ctx, g);
	drawVignette(ctx, w, h);
	if (g.flash > .01) {
		ctx.fillStyle = `rgba(255, 236, 214, ${Math.min(.7, g.flash)})`;
		ctx.fillRect(0, 0, w, h);
	}
}
function drawNebula(ctx, g) {
	for (const b of [
		{
			x: .18,
			y: .22,
			r: .42,
			c: "rgba(90, 40, 140, 0.28)",
			d: .08
		},
		{
			x: .78,
			y: .18,
			r: .36,
			c: "rgba(20, 70, 110, 0.26)",
			d: .12
		},
		{
			x: .55,
			y: .62,
			r: .4,
			c: "rgba(120, 30, 70, 0.12)",
			d: .05
		}
	]) {
		const scroll = g.camera * b.d % (g.width + 200);
		const x = ((b.x * g.width - scroll) % (g.width + 180) + g.width + 180) % (g.width + 180) - 40;
		const y = b.y * g.height;
		const r = b.r * Math.max(g.width, g.height);
		const grad = ctx.createRadialGradient(x, y, 0, x, y, r);
		grad.addColorStop(0, b.c);
		grad.addColorStop(1, "rgba(0,0,0,0)");
		ctx.fillStyle = grad;
		ctx.fillRect(0, 0, g.width, g.height);
	}
}
function drawWormhole(ctx, g) {
	const x = g.width * .74 - g.camera * .04 % 80;
	const y = g.height * .26;
	const rx = Math.min(g.width, g.height) * .16;
	const ry = rx * .42;
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(g.time * .15);
	for (let i = 3; i >= 0; i--) {
		ctx.beginPath();
		ctx.ellipse(0, 0, rx * (.55 + i * .18), ry * (.55 + i * .18), 0, 0, Math.PI * 2);
		ctx.strokeStyle = `hsla(${(g.time * 40 + i * 40) % 360}, 90%, 68%, ${.18 - i * .03})`;
		ctx.lineWidth = 3;
		ctx.stroke();
	}
	ctx.restore();
}
function drawStars(ctx, g) {
	for (const s of g.stars) {
		const scroll = g.camera * s.depth + g.time * 8 * s.depth;
		const x = ((s.x * g.width - scroll) % g.width + g.width) % g.width;
		const y = s.y * (g.groundY - 8);
		ctx.globalAlpha = .45 + .55 * (.5 + .5 * Math.sin(g.time * 2.2 + s.tw));
		ctx.fillStyle = s.depth > .7 ? "#fff6e4" : "#c9c2dc";
		ctx.fillRect(x, y, s.size, s.size);
	}
	ctx.globalAlpha = 1;
}
function drawStreaks(ctx, g) {
	ctx.globalAlpha = .25;
	ctx.strokeStyle = "#efe8ff";
	ctx.lineWidth = 1;
	for (let i = 0; i < 10; i++) {
		const y = hash$1(i + 4) * g.groundY;
		const x = ((hash$1(i + 9) * g.width - g.time * (180 + i * 30) - g.camera * .2) % g.width + g.width) % g.width;
		ctx.beginPath();
		ctx.moveTo(x, y);
		ctx.lineTo(x + 18 + i % 4 * 8, y);
		ctx.stroke();
	}
	ctx.globalAlpha = 1;
}
function drawGround(ctx, g) {
	const y = g.groundY;
	const band = ctx.createLinearGradient(0, y - 40, 0, g.height);
	band.addColorStop(0, "rgba(122, 92, 255, 0)");
	band.addColorStop(.12, "rgba(88, 54, 170, 0.22)");
	band.addColorStop(.45, "rgba(28, 16, 58, 0.35)");
	band.addColorStop(1, "rgba(7, 6, 14, 0)");
	ctx.fillStyle = band;
	ctx.fillRect(0, y - 36, g.width, g.height - y + 36);
	const heat = Math.min(1, g.speed / Math.max(1, g.maxSpeed));
	traceRibbon(ctx, g, y, 0);
	ctx.strokeStyle = `rgba(255, 211, 106, ${.55 + heat * .4})`;
	ctx.lineWidth = 2.25;
	ctx.stroke();
	traceRibbon(ctx, g, y + 5, 1.4);
	ctx.strokeStyle = `rgba(126, 240, 255, ${.28 + heat * .35})`;
	ctx.lineWidth = 1.5;
	ctx.stroke();
	ctx.globalAlpha = .55;
	for (let i = 0; i < 14; i++) {
		const span = 90;
		const x = ((i * span - g.camera * (1.15 + i % 3 * .05)) % (g.width + span) + g.width + span) % (g.width + span) - 20;
		const yy = y + 10 + Math.sin(g.time * 2 + i) * 4;
		ctx.fillStyle = i % 2 === 0 ? "#ffd36a" : "#7ef0ff";
		ctx.beginPath();
		ctx.arc(x, yy, 1.4, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
}
function traceRibbon(ctx, g, y, phase) {
	ctx.beginPath();
	for (let x = 0; x <= g.width; x += 8) {
		const yy = y + Math.sin(x * .018 + g.time * 1.8 + g.camera * .012 + phase) * 4.5;
		if (x === 0) ctx.moveTo(x, yy);
		else ctx.lineTo(x, yy);
	}
}
function drawObstacle(ctx, g, o) {
	const x = o.x - g.camera;
	if (x > g.width + 40 || x + o.w < -40) return;
	if (o.kind === "crystal") drawCrystal(ctx, x, g.groundY, o);
	else if (o.kind === "satellite") drawSatellite(ctx, x, g.groundY, o, g.time);
	else drawRock(ctx, x, g.groundY, o);
}
function drawRock(ctx, x, ground, o) {
	const cx = x + o.w / 2;
	const tint = o.kind === "boulder" ? 28 : 18;
	ctx.beginPath();
	const pts = o.pts;
	for (let i = 0; i < pts.length; i++) {
		const px = cx + pts[i].x;
		const py = ground + pts[i].y;
		if (i === 0) ctx.moveTo(px, py);
		else ctx.lineTo(px, py);
	}
	ctx.closePath();
	const grad = ctx.createLinearGradient(cx, ground - o.h, cx, ground);
	grad.addColorStop(0, `rgb(${118 + tint}, ${108 + tint}, ${138 + tint})`);
	grad.addColorStop(.45, `rgb(${64 + tint}, ${56 + tint}, 84)`);
	grad.addColorStop(1, "#1a1626");
	ctx.fillStyle = grad;
	ctx.fill();
	ctx.strokeStyle = "rgba(255, 230, 190, 0.28)";
	ctx.lineWidth = 1.25;
	ctx.stroke();
	const rnd = mulberry(o.seed + 9);
	for (let i = 0; i < 3; i++) {
		const px = cx + (rnd() - .5) * o.w * .5;
		const py = ground - o.h * (.25 + rnd() * .45);
		ctx.fillStyle = "rgba(10, 8, 16, 0.35)";
		ctx.beginPath();
		ctx.ellipse(px, py, o.w * .08, o.h * .06, 0, 0, Math.PI * 2);
		ctx.fill();
	}
}
function drawCrystal(ctx, x, ground, o) {
	const cx = x + o.w / 2;
	ctx.beginPath();
	for (let i = 0; i < o.pts.length; i++) {
		const px = cx + o.pts[i].x;
		const py = ground + o.pts[i].y;
		if (i === 0) ctx.moveTo(px, py);
		else ctx.lineTo(px, py);
	}
	ctx.closePath();
	const grad = ctx.createLinearGradient(cx, ground - o.h, cx + o.w, ground);
	grad.addColorStop(0, "#e8fbff");
	grad.addColorStop(.35, "#7ef0ff");
	grad.addColorStop(.7, "#c9b6ff");
	grad.addColorStop(1, "#ff5d9a");
	ctx.fillStyle = grad;
	ctx.globalAlpha = .92;
	ctx.fill();
	ctx.globalAlpha = 1;
	ctx.strokeStyle = "rgba(255,255,255,0.65)";
	ctx.lineWidth = 1.2;
	ctx.stroke();
	ctx.beginPath();
	ctx.moveTo(cx, ground - o.h * .92);
	ctx.lineTo(cx + o.w * .12, ground - o.h * .2);
	ctx.lineTo(cx - o.w * .06, ground - o.h * .15);
	ctx.closePath();
	ctx.fillStyle = "rgba(255,255,255,0.38)";
	ctx.fill();
}
function drawSatellite(ctx, x, ground, o, time) {
	const base = ground - o.h * .15;
	const bodyW = o.w * .34;
	const bodyH = o.h * .55;
	const bx = x + o.w / 2 - bodyW / 2;
	const by = base - bodyH;
	ctx.fillStyle = "#8fd0ff";
	ctx.globalAlpha = .85;
	ctx.fillRect(x, by + bodyH * .25, o.w * .28, bodyH * .28);
	ctx.fillRect(x + o.w * .72, by + bodyH * .25, o.w * .28, bodyH * .28);
	ctx.globalAlpha = 1;
	ctx.strokeStyle = "rgba(180, 220, 255, 0.7)";
	ctx.strokeRect(x, by + bodyH * .25, o.w * .28, bodyH * .28);
	ctx.strokeRect(x + o.w * .72, by + bodyH * .25, o.w * .28, bodyH * .28);
	roundRect(ctx, bx, by, bodyW, bodyH, 6);
	const grad = ctx.createLinearGradient(bx, by, bx, by + bodyH);
	grad.addColorStop(0, "#d7dde8");
	grad.addColorStop(1, "#5c6478");
	ctx.fillStyle = grad;
	ctx.fill();
	ctx.strokeStyle = "#ffd36a";
	ctx.lineWidth = 1.5;
	ctx.beginPath();
	ctx.arc(bx + bodyW / 2, by - o.h * .08, o.h * .22, Math.PI, 0);
	ctx.stroke();
	ctx.fillStyle = `rgba(255, 93, 122, ${.4 + .6 * (.5 + .5 * Math.sin(time * 6 + o.seed))})`;
	ctx.beginPath();
	ctx.arc(bx + bodyW - 6, by + 7, 2.4, 0, Math.PI * 2);
	ctx.fill();
	ctx.strokeStyle = "#3a4154";
	ctx.lineWidth = 2;
	ctx.beginPath();
	ctx.moveTo(x + o.w / 2, base);
	ctx.lineTo(x + o.w / 2, ground);
	ctx.stroke();
}
function drawStarPickup(ctx, g, p) {
	const x = p.x - g.camera;
	if (x < -30 || x > g.width + 30) return;
	const y = p.y + Math.sin(g.time * 4 + p.phase) * 5;
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(g.time * 1.6 + p.phase);
	ctx.shadowColor = "rgba(255, 211, 106, 0.85)";
	ctx.shadowBlur = 12;
	starPath(ctx, 0, 0, p.r, 0);
	ctx.fillStyle = "#ffd36a";
	ctx.fill();
	ctx.shadowBlur = 0;
	starPath(ctx, 0, 0, p.r * .45, .4);
	ctx.fillStyle = "#fff6dd";
	ctx.fill();
	ctx.restore();
}
function drawParticles(ctx, g) {
	for (const p of g.particles) {
		if (!p.alive) continue;
		const a = Math.max(0, p.life / p.max);
		ctx.globalAlpha = a;
		ctx.fillStyle = `hsl(${p.hue}, 95%, 64%)`;
		ctx.beginPath();
		ctx.arc(p.x, p.y, p.size * a, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
}
function drawShadow(ctx, g) {
	const alt = Math.max(0, g.groundY - g.radius - g.wormY) / Math.max(1, g.jumpH);
	const a = Math.max(.05, .38 - alt * .32);
	const sx = g.radius * (1.15 - alt * .45);
	ctx.fillStyle = `rgba(0, 0, 0, ${a})`;
	ctx.beginPath();
	ctx.ellipse(g.headX, g.groundY + 2, sx, g.radius * .28, 0, 0, Math.PI * 2);
	ctx.fill();
}
function drawWorm(ctx, g) {
	const segs = g.segs;
	const n = g.segCount;
	if (n < 2) return;
	const headR = g.radius;
	const hueBase = g.time * 80;
	ctx.beginPath();
	ctx.moveTo(segs[n - 1].x, segs[n - 1].y);
	for (let i = n - 2; i >= 0; i--) ctx.lineTo(segs[i].x, segs[i].y);
	ctx.lineCap = "round";
	ctx.lineJoin = "round";
	ctx.strokeStyle = "rgba(8, 4, 16, 0.45)";
	ctx.lineWidth = headR * 1.45;
	ctx.stroke();
	for (let i = n - 1; i >= 1; i--) {
		const t = i / (n - 1);
		const r = headR * (1.05 - t * .62);
		const hue = (hueBase + (1 - t) * 300) % 360;
		const wob = g.dead ? 0 : Math.sin(g.time * 7 - i * .55) * r * .06;
		const x = segs[i].x;
		const y = segs[i].y + wob;
		ctx.fillStyle = `hsla(${hue}, 95%, 62%, 0.28)`;
		ctx.beginPath();
		ctx.arc(x, y, r * 1.35, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = `hsl(${hue}, 92%, ${60 - t * 12}%)`;
		ctx.beginPath();
		ctx.arc(x, y, r, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = `hsla(${hue}, 100%, 90%, 0.7)`;
		ctx.beginPath();
		ctx.ellipse(x - r * .28, y - r * .32, r * .26, r * .16, -.5, 0, Math.PI * 2);
		ctx.fill();
	}
	const head = segs[0];
	const hue = hueBase % 360;
	ctx.save();
	ctx.translate(head.x, head.y);
	ctx.rotate(g.dead ? g.spin : Math.atan2(g.wormVy, 900) * .35);
	ctx.scale(1 / g.stretch, g.stretch);
	const flap = .4 + Math.abs(Math.sin(g.time * (g.mode === "play" ? 16 : 8))) * .75;
	ctx.fillStyle = `hsla(${(hue + 40) % 360}, 100%, 70%, 0.32)`;
	ctx.beginPath();
	ctx.ellipse(-headR * .15, -headR * .05, headR * 1.15, headR * .38 * flap, -.7, 0, Math.PI * 2);
	ctx.fill();
	ctx.beginPath();
	ctx.ellipse(-headR * .05, headR * .28, headR * .9, headR * .28 * flap, .55, 0, Math.PI * 2);
	ctx.fill();
	const grd = ctx.createRadialGradient(-headR * .35, -headR * .4, headR * .15, 0, 0, headR);
	grd.addColorStop(0, `hsl(${hue}, 100%, 82%)`);
	grd.addColorStop(.55, `hsl(${hue}, 95%, 60%)`);
	grd.addColorStop(1, `hsl(${(hue + 24) % 360}, 90%, 40%)`);
	ctx.fillStyle = grd;
	ctx.beginPath();
	ctx.arc(0, 0, headR, 0, Math.PI * 2);
	ctx.fill();
	drawAntenna(ctx, headR, hue, -.7, g.time);
	drawAntenna(ctx, headR, (hue + 50) % 360, .15, g.time + .4);
	const blink = g.blink > 0 ? Math.max(.08, 1 - g.blink * 8) : 1;
	const look = Math.max(-1, Math.min(1, -g.wormVy / 700));
	drawEye(ctx, headR * .12, -headR * .12, headR * .34, blink, g.dead, look);
	drawEye(ctx, headR * .48, -headR * .02, headR * .28, blink, g.dead, look);
	ctx.fillStyle = "rgba(255, 140, 170, 0.45)";
	ctx.beginPath();
	ctx.ellipse(-headR * .05, headR * .22, headR * .16, headR * .09, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.strokeStyle = "rgba(50, 16, 28, 0.75)";
	ctx.lineWidth = Math.max(1.25, headR * .07);
	ctx.lineCap = "round";
	ctx.beginPath();
	if (g.dead) {
		ctx.moveTo(headR * .05, headR * .32);
		ctx.lineTo(headR * .4, headR * .32);
	} else ctx.arc(headR * .18, headR * .18, headR * .26, .2, Math.PI - .35);
	ctx.stroke();
	ctx.restore();
}
function drawAntenna(ctx, r, hue, ang, time) {
	const sway = Math.sin(time * 5) * .18;
	ctx.strokeStyle = `hsl(${hue}, 90%, 70%)`;
	ctx.lineWidth = Math.max(1.4, r * .07);
	ctx.beginPath();
	ctx.moveTo(r * .1, -r * .7);
	ctx.quadraticCurveTo(r * (.2 + ang), -r * 1.15, r * (.15 + ang + sway), -r * 1.45);
	ctx.stroke();
	ctx.fillStyle = `hsl(${(hue + 30) % 360}, 100%, 72%)`;
	ctx.beginPath();
	ctx.arc(r * (.15 + ang + sway), -r * 1.45, r * .14, 0, Math.PI * 2);
	ctx.fill();
}
function drawEye(ctx, x, y, r, blink, dead, look) {
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(1, blink);
	if (dead) {
		ctx.strokeStyle = "#241018";
		ctx.lineWidth = Math.max(1.5, r * .28);
		ctx.beginPath();
		ctx.moveTo(-r, -r);
		ctx.lineTo(r, r);
		ctx.moveTo(r, -r);
		ctx.lineTo(-r, r);
		ctx.stroke();
	} else {
		ctx.fillStyle = "#fffaf4";
		ctx.beginPath();
		ctx.arc(0, 0, r, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#1a1020";
		ctx.beginPath();
		ctx.arc(r * .2, r * .15 + look * r * .35, r * .48, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#fff";
		ctx.beginPath();
		ctx.arc(-r * .15, -r * .25, r * .18, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.restore();
}
function drawFloaters(ctx, g) {
	ctx.font = `700 ${Math.round(16 * g.scale)}px Outfit, ui-sans-serif, sans-serif`;
	ctx.textAlign = "center";
	for (const f of g.floaters) {
		if (!f.alive) continue;
		const a = Math.max(0, f.life / f.max);
		const t = 1 - a;
		ctx.globalAlpha = a;
		ctx.fillStyle = "#ffd36a";
		ctx.fillText(f.text, f.x, f.y - t * 28);
	}
	ctx.globalAlpha = 1;
}
function drawVignette(ctx, w, h) {
	const v = ctx.createRadialGradient(w / 2, h * .45, h * .25, w / 2, h * .5, h * .78);
	v.addColorStop(0, "rgba(0,0,0,0)");
	v.addColorStop(1, "rgba(0,0,0,0.42)");
	ctx.fillStyle = v;
	ctx.fillRect(0, 0, w, h);
}
function starPath(ctx, x, y, r, rot) {
	ctx.beginPath();
	for (let i = 0; i < 5; i++) {
		const a = rot + i * Math.PI * 2 / 5 - Math.PI / 2;
		const b = a + Math.PI / 5;
		const ox = x + Math.cos(a) * r;
		const oy = y + Math.sin(a) * r;
		const ix = x + Math.cos(b) * r * .42;
		const iy = y + Math.sin(b) * r * .42;
		if (i === 0) ctx.moveTo(ox, oy);
		else ctx.lineTo(ox, oy);
		ctx.lineTo(ix, iy);
	}
	ctx.closePath();
}
function roundRect(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.arcTo(x + w, y, x + w, y + h, r);
	ctx.arcTo(x + w, y + h, x, y + h, r);
	ctx.arcTo(x, y + h, x, y, r);
	ctx.arcTo(x, y, x + w, y, r);
	ctx.closePath();
}
function mulberry(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
var SAVE_KEY = "rainbow-worm-v1";
var STEP = 1 / 60;
var HIST = 640;
var AIR = .62;
var COYOTE = .1;
var BUFFER = .13;
function hash(n) {
	const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
	return x - Math.floor(x);
}
function randMulberry(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function loadSave() {
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return {
			best: 0,
			mute: false
		};
		const parsed = JSON.parse(raw);
		return {
			best: Number(parsed.best) || 0,
			mute: !!parsed.mute
		};
	} catch {
		return {
			best: 0,
			mute: false
		};
	}
}
var RainbowEngine = class {
	mode = "menu";
	camera = 0;
	time = 0;
	speed = 280;
	maxSpeed = 640;
	baseSpeed = 280;
	width = 360;
	height = 640;
	groundY = 480;
	headX = 90;
	radius = 22;
	scale = 1;
	jumpH = 140;
	jumpV = 700;
	grav = 2200;
	hitR = 12;
	spacing = 16;
	segCount = 16;
	best = 0;
	bestAtStart = 0;
	stars = 0;
	near = 0;
	spawned = 0;
	nextSpawn = 800;
	flash = 0;
	trauma = 0;
	hitstop = 0;
	deathAge = 0;
	stretch = 1;
	blink = 0;
	blinkIn = 2.4;
	spin = 0;
	scrollLeft = 0;
	reduce;
	worm = {
		y: 400,
		vy: 0,
		grounded: true,
		coyote: COYOTE,
		buffer: 0
	};
	segs = [];
	obstacles = [];
	pickups = [];
	particles = [];
	floaters = [];
	starfield = [];
	histX = new Float32Array(HIST);
	histY = new Float32Array(HIST);
	histHead = 0;
	histCount = 0;
	acc = 0;
	dpr = 1;
	raf = 0;
	last = 0;
	running = true;
	spawnSeed = 1;
	recordLive = false;
	ctx2d = null;
	keyJump = false;
	padJump = false;
	padWas = false;
	pointers = /* @__PURE__ */ new Set();
	pressEdge = false;
	releaseEdge = false;
	sfx = new Sfx();
	onEvent;
	hud;
	canvas;
	ro;
	onKeyDown;
	onKeyUp;
	onPointerDown;
	onPointerUp;
	onBlur;
	onVis;
	constructor(canvas, hud, onEvent) {
		this.canvas = canvas;
		this.hud = hud;
		this.onEvent = onEvent;
		const save = loadSave();
		this.best = save.best;
		this.bestAtStart = save.best;
		this.sfx.muted = save.mute;
		this.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.ctx2d = canvas.getContext("2d", { alpha: false });
		for (let i = 0; i < 18; i++) this.segs.push({
			x: 0,
			y: 0
		});
		for (let i = 0; i < 14; i++) this.obstacles.push({
			active: false,
			x: 0,
			y: 0,
			w: 40,
			h: 40,
			kind: "pebble",
			seed: 1,
			passed: false,
			pts: []
		});
		for (let i = 0; i < 16; i++) this.pickups.push({
			active: false,
			x: 0,
			y: 0,
			phase: 0,
			r: 12
		});
		for (let i = 0; i < 180; i++) this.particles.push({
			alive: false,
			x: 0,
			y: 0,
			vx: 0,
			vy: 0,
			life: 0,
			max: 1,
			size: 2,
			hue: 0,
			grav: 0
		});
		for (let i = 0; i < 10; i++) this.floaters.push({
			alive: false,
			x: 0,
			y: 0,
			text: "",
			life: 0,
			max: 1
		});
		for (let i = 0; i < 96; i++) this.starfield.push({
			x: hash(i * 3 + 1),
			y: hash(i * 3 + 2),
			depth: .15 + hash(i * 3 + 3) * .85,
			size: .8 + hash(i * 7) * 1.8,
			tw: hash(i * 9) * Math.PI * 2
		});
		this.onKeyDown = (e) => {
			if (e.repeat) return;
			if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") {
				e.preventDefault();
				this.setKeyJump(true);
			} else if (e.code === "Escape" || e.code === "KeyP") this.togglePause();
			else if (e.code === "KeyM") this.toggleMute();
			else if (e.code === "KeyR" && this.mode === "dead") this.restart();
		};
		this.onKeyUp = (e) => {
			if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") this.setKeyJump(false);
		};
		this.onPointerDown = (e) => {
			if (fromUi(e)) return;
			this.pointers.add(e.pointerId);
			if (this.pointers.size === 1 && !this.keyJump && !this.padJump) this.notePress();
			else if (!this.held()) this.notePress();
			e.preventDefault();
		};
		this.onPointerUp = (e) => {
			this.pointers.delete(e.pointerId);
			if (!this.held()) this.noteRelease();
		};
		this.onBlur = () => {
			this.keyJump = false;
			this.pointers.clear();
			this.padJump = false;
		};
		this.onVis = () => {
			if (document.visibilityState === "visible") this.sfx.resume();
			else this.persist();
		};
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("pointerdown", this.onPointerDown, { passive: false });
		window.addEventListener("pointerup", this.onPointerUp);
		window.addEventListener("pointercancel", this.onPointerUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onVis);
		this.ro = new ResizeObserver(() => this.resize());
		this.ro.observe(canvas);
		this.resize();
		this.placeBody(true);
		this.syncHud();
		this.onEvent({
			type: "mute",
			muted: this.sfx.muted
		});
		this.last = performance.now();
		const loop = (now) => {
			if (!this.running) return;
			const dt = Math.min(.05, (now - this.last) / 1e3);
			this.last = now;
			this.frame(dt);
			this.raf = requestAnimationFrame(loop);
		};
		this.raf = requestAnimationFrame(loop);
		const w = window;
		w.__rainbow = {
			mode: () => this.mode,
			camera: () => this.camera,
			y: () => this.worm.y,
			grounded: () => this.worm.grounded,
			score: () => this.score,
			stars: () => this.stars,
			best: () => this.best
		};
	}
	get score() {
		return Math.floor(this.camera / 42) + this.stars * 15 + this.near * 25;
	}
	get muted() {
		return this.sfx.muted;
	}
	destroy() {
		this.running = false;
		cancelAnimationFrame(this.raf);
		this.ro.disconnect();
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("pointerdown", this.onPointerDown);
		window.removeEventListener("pointerup", this.onPointerUp);
		window.removeEventListener("pointercancel", this.onPointerUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onVis);
		this.sfx.close();
		const w = window;
		delete w.__rainbow;
	}
	start(withJump) {
		this.sfx.unlock();
		this.sfx.musicOn = true;
		this.mode = "play";
		this.camera = 0;
		this.stars = 0;
		this.near = 0;
		this.spawned = 0;
		this.flash = 0;
		this.trauma = 0;
		this.hitstop = 0;
		this.deathAge = 0;
		this.spin = 0;
		this.scrollLeft = 0;
		this.recordLive = false;
		this.bestAtStart = this.best;
		this.worm.vy = 0;
		this.worm.grounded = true;
		this.worm.coyote = COYOTE;
		this.worm.buffer = 0;
		this.worm.y = this.groundY - this.radius;
		this.speed = this.baseSpeed;
		this.nextSpawn = this.width + this.baseSpeed * 1.15;
		for (const o of this.obstacles) o.active = false;
		for (const p of this.pickups) p.active = false;
		for (const f of this.floaters) f.alive = false;
		this.seedHistory();
		this.placeBody(false);
		this.hud.stage.dataset.record = "0";
		this.onEvent({
			type: "mode",
			mode: "play"
		});
		this.onEvent({ type: "start" });
		if (withJump) this.pressEdge = true;
		this.syncHud();
	}
	restart() {
		if (this.mode !== "dead" && this.mode !== "menu") return;
		this.start(false);
	}
	toMenu() {
		this.mode = "menu";
		this.worm.vy = 0;
		this.worm.grounded = true;
		this.flash = 0;
		this.sfx.musicOn = true;
		this.onEvent({
			type: "mode",
			mode: "menu"
		});
	}
	togglePause() {
		if (this.mode === "play") {
			this.mode = "pause";
			this.persist();
			this.onEvent({
				type: "mode",
				mode: "pause"
			});
		} else if (this.mode === "pause") {
			this.mode = "play";
			this.onEvent({
				type: "mode",
				mode: "play"
			});
		}
	}
	toggleMute() {
		this.sfx.unlock();
		const muted = this.sfx.toggleMuted();
		this.persist();
		this.onEvent({
			type: "mute",
			muted
		});
		return muted;
	}
	held() {
		return this.keyJump || this.padJump || this.pointers.size > 0;
	}
	notePress() {
		this.sfx.unlock();
		this.sfx.musicOn = true;
		if (this.mode === "menu") {
			this.start(true);
			return;
		}
		if (this.mode === "dead") {
			this.start(true);
			return;
		}
		if (this.mode === "pause") {
			this.mode = "play";
			this.onEvent({
				type: "mode",
				mode: "play"
			});
		}
		this.pressEdge = true;
	}
	noteRelease() {
		this.releaseEdge = true;
	}
	setKeyJump(down) {
		if (down) {
			const was = this.held();
			this.keyJump = true;
			if (!was) this.notePress();
		} else {
			this.keyJump = false;
			if (!this.held()) this.noteRelease();
		}
	}
	frame(dt) {
		this.pollPad();
		if (this.hitstop > 0) {
			this.hitstop -= dt;
			this.draw();
			return;
		}
		this.acc += dt;
		let steps = 0;
		while (this.acc >= STEP && steps < 5) {
			this.step(STEP);
			this.acc -= STEP;
			steps++;
		}
		this.trauma = Math.max(0, this.trauma - dt * 1.7);
		this.flash = Math.max(0, this.flash - dt * 1.8);
		this.sfx.pump();
		this.syncHud();
		this.draw();
	}
	step(dt) {
		this.time += dt;
		this.blinkIn -= dt;
		if (this.blinkIn <= 0) {
			this.blink = .14;
			this.blinkIn = 2.6 + Math.random() * 2.2;
		}
		if (this.blink > 0) this.blink -= dt;
		if (this.mode === "play") this.stepPlay(dt);
		else if (this.mode === "dead") this.stepDead(dt);
		else if (this.mode === "menu") this.stepMenu(dt);
		if (this.mode === "play" || this.mode === "dead") {
			const targetStretch = Math.max(.78, Math.min(1.32, 1 + -this.worm.vy / (this.jumpV * 1.6)));
			this.stretch += (targetStretch - this.stretch) * (1 - Math.exp(-12 * dt));
		}
		this.updateParticles(dt);
		this.updateFloaters(dt);
		this.placeBody(this.mode === "menu");
	}
	stepMenu(dt) {
		const base = this.groundY - this.radius;
		this.worm.y = base + Math.sin(this.time * 2.2) * (8 * this.scale);
		this.worm.vy = Math.cos(this.time * 2.2) * 40;
		this.camera += this.baseSpeed * .18 * dt;
		if (Math.random() < .25) this.emit(this.headX - this.radius, this.worm.y, 1, this.time * 80 % 360, 30);
	}
	stepPlay(dt) {
		const dist = this.camera;
		this.speed = Math.min(this.maxSpeed, this.baseSpeed + dist * .035);
		this.camera += this.speed * dt;
		this.integrateWorm(dt, true);
		this.pushHist(this.camera + this.headX, this.worm.y);
		let guard = 0;
		while (this.nextSpawn < this.camera + this.width + 50 && guard++ < 4) this.spawnObstacle();
		const hx = this.camera + this.headX;
		const prevHx = hx - this.speed * dt;
		for (const o of this.obstacles) {
			if (!o.active) continue;
			if (o.x + o.w < this.camera - 80) {
				o.active = false;
				continue;
			}
			if (this.hits(prevHx, this.worm.y - this.worm.vy * dt, hx, this.worm.y, o)) {
				this.die();
				return;
			}
			if (!o.passed && o.x + o.w < hx) {
				o.passed = true;
				const clearance = o.y - (this.worm.y + this.hitR);
				if (clearance > -4 && clearance < 30 * this.scale && !this.worm.grounded) {
					this.near++;
					this.floater(this.headX, this.worm.y - this.radius - 8, "+25");
					this.sfx.near();
					this.bump(.22);
				}
			}
		}
		for (const p of this.pickups) {
			if (!p.active) continue;
			if (p.x < this.camera - 40) {
				p.active = false;
				continue;
			}
			const dx = hx - p.x;
			const dy = this.worm.y - p.y;
			if (dx * dx + dy * dy < (this.hitR + p.r) * (this.hitR + p.r)) {
				p.active = false;
				this.stars++;
				this.floater(this.headX + 10, this.worm.y - this.radius, "+15");
				this.sfx.star();
				this.emit(this.headX, this.worm.y, 10, 48, 160);
			}
		}
		if (this.score > this.bestAtStart && !this.recordLive) {
			this.recordLive = true;
			this.hud.stage.dataset.record = "1";
		}
		if (this.time * 60 % 2 < 1) {
			const tail = this.segs[Math.min(this.segs.length - 1, this.segCount - 1)];
			if (tail) this.emit(tail.x, tail.y, 1, this.time * 90 % 360, 20);
		}
	}
	stepDead(dt) {
		this.deathAge += dt;
		this.scrollLeft = Math.max(0, this.speed * Math.exp(-this.deathAge * 2.4));
		this.camera += this.scrollLeft * dt;
		this.spin += dt * 6;
		this.integrateWorm(dt, false);
		this.pushHist(this.camera + this.headX, this.worm.y);
	}
	integrateWorm(dt, canJump) {
		if (canJump) {
			if (this.pressEdge) {
				this.worm.buffer = BUFFER;
				this.pressEdge = false;
			}
			if (this.worm.grounded) this.worm.coyote = COYOTE;
			else this.worm.coyote = Math.max(0, this.worm.coyote - dt);
			this.worm.buffer = Math.max(0, this.worm.buffer - dt);
			if (this.worm.buffer > 0 && (this.worm.grounded || this.worm.coyote > 0)) this.doJump();
			if (this.releaseEdge) {
				const minV = this.jumpV * .56;
				if (this.worm.vy < -minV) this.worm.vy = -minV;
				this.releaseEdge = false;
			}
		} else {
			this.pressEdge = false;
			this.releaseEdge = false;
		}
		this.worm.vy += this.grav * dt;
		if (this.worm.vy > this.jumpV * 1.35) this.worm.vy = this.jumpV * 1.35;
		this.worm.y += this.worm.vy * dt;
		const floor = this.groundY - this.radius;
		if (this.worm.y >= floor) {
			const impact = this.worm.vy;
			this.worm.y = floor;
			this.worm.vy = 0;
			if (!this.worm.grounded) {
				this.worm.grounded = true;
				this.stretch = .74;
				if (impact > 240) {
					this.sfx.land();
					this.emit(this.headX, floor + this.radius * .2, 6, 40, 90);
					this.bump(.12);
				}
			} else this.worm.grounded = true;
		} else if (this.worm.vy < -40 || this.worm.y < floor - 2) this.worm.grounded = false;
		const ceil = this.radius + 8;
		if (this.worm.y < ceil) {
			this.worm.y = ceil;
			if (this.worm.vy < 0) this.worm.vy = 0;
		}
	}
	doJump() {
		this.worm.vy = -this.jumpV;
		this.worm.grounded = false;
		this.worm.coyote = 0;
		this.worm.buffer = 0;
		this.stretch = 1.28;
		this.sfx.jump();
		this.emit(this.headX, this.groundY, 8, this.time * 80 % 360, 120);
	}
	die() {
		this.mode = "dead";
		this.deathAge = 0;
		this.hitstop = this.reduce ? 0 : .07;
		this.flash = .65;
		this.bump(.8);
		this.worm.vy = -this.jumpV * .45;
		this.worm.grounded = false;
		this.sfx.crash();
		this.emit(this.headX, this.worm.y, 36, this.time * 40 % 360, 280);
		const stats = this.finishStats();
		this.onEvent({
			type: "over",
			stats
		});
		this.onEvent({
			type: "mode",
			mode: "dead"
		});
	}
	finishStats() {
		const score = this.score;
		const isNewBest = score > this.best;
		if (isNewBest) this.best = score;
		this.persist();
		return {
			score,
			best: this.best,
			stars: this.stars,
			near: this.near,
			distance: Math.floor(this.camera / 42),
			isNewBest
		};
	}
	spawnObstacle() {
		const o = this.obstacles.find((item) => !item.active);
		if (!o) {
			this.nextSpawn += 200;
			return;
		}
		const rnd = randMulberry(this.spawnSeed = this.spawnSeed * 1664525 + 1013904223 >>> 0);
		const kind = this.pickKind(rnd);
		const jumpDist = this.speed * AIR;
		const maxH = this.jumpH * (kind === "pebble" ? .34 : kind === "crystal" ? .74 : .55);
		const maxW = Math.max(34 * this.scale, jumpDist * (kind === "satellite" ? .34 : .28));
		let w = 40;
		let h = 36;
		if (kind === "pebble") {
			w = (30 + rnd() * 16) * this.scale;
			h = (28 + rnd() * 16) * this.scale;
		} else if (kind === "boulder") {
			w = (46 + rnd() * 26) * this.scale;
			h = (46 + rnd() * 22) * this.scale;
		} else if (kind === "crystal") {
			w = (28 + rnd() * 14) * this.scale;
			h = (72 + rnd() * 28) * this.scale;
		} else {
			w = (68 + rnd() * 26) * this.scale;
			h = (36 + rnd() * 16) * this.scale;
		}
		w = Math.min(w, maxW);
		h = Math.min(h, Math.max(26 * this.scale, maxH));
		o.active = true;
		o.kind = kind;
		o.seed = rnd() * 1e9 >>> 0;
		o.w = w;
		o.h = h;
		o.x = Math.max(this.nextSpawn, this.camera + this.headX + 120);
		o.y = this.groundY - h;
		o.passed = false;
		o.pts = makePts(kind, o.seed, w, h);
		this.spawned++;
		if (rnd() < .62) this.tryStarAbove(o, rnd);
		const gapTime = .98 + rnd() * .55;
		const gap = this.speed * gapTime;
		if (rnd() < .55) {
			const sx = o.x + o.w + gap * (.35 + rnd() * .3);
			const sy = this.groundY - this.radius - this.jumpH * (.28 + rnd() * .4);
			this.activateStar(sx, sy);
		}
		this.nextSpawn = o.x + o.w + gap;
	}
	pickKind(rnd) {
		if (this.spawned < 3) return "pebble";
		if (this.camera < 1600) return rnd() < .72 ? "pebble" : "boulder";
		const r = rnd();
		if (r < .34) return "pebble";
		if (r < .62) return "boulder";
		if (r < .82) return "crystal";
		return "satellite";
	}
	tryStarAbove(o, rnd) {
		const minY = this.groundY - this.radius - this.jumpH + 16;
		const maxY = this.groundY - this.radius - 48 * this.scale;
		let sy = o.y - 18 * this.scale;
		if (sy < minY) sy = minY + rnd() * 8;
		if (sy > maxY || sy + 14 > o.y) return;
		this.activateStar(o.x + o.w * .5, sy);
	}
	activateStar(x, y) {
		const p = this.pickups.find((item) => !item.active);
		if (!p) return;
		p.active = true;
		p.x = x;
		p.y = y;
		p.phase = Math.random() * Math.PI * 2;
		p.r = 11 * this.scale;
	}
	hits(x0, y0, x1, y1, o) {
		const inset = Math.min(5 * this.scale, o.w * .1, o.h * .1);
		const rx = o.x + inset;
		const ry = o.y + inset;
		const rw = Math.max(4, o.w - inset * 2);
		const rh = Math.max(4, o.h - inset * 2);
		for (let i = 0; i <= 4; i++) {
			const t = i / 4;
			if (circleRect(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, this.hitR, rx, ry, rw, rh)) return true;
		}
		return false;
	}
	seedHistory() {
		this.histCount = 0;
		this.histHead = 0;
		const y = this.groundY - this.radius;
		for (let i = 280; i >= 0; i--) this.pushHist(this.headX - i * 3, y);
	}
	pushHist(x, y) {
		this.histX[this.histHead] = x;
		this.histY[this.histHead] = y;
		this.histHead = (this.histHead + 1) % HIST;
		if (this.histCount < HIST) this.histCount++;
	}
	placeBody(scripted) {
		const n = this.segCount;
		if (scripted) {
			for (let i = 0; i < n; i++) {
				this.segs[i].x = this.headX - i * this.spacing;
				this.segs[i].y = this.worm.y + Math.sin(this.time * 3 - i * .45) * (6 * this.scale);
			}
			return;
		}
		this.segs[0].x = this.headX;
		this.segs[0].y = this.worm.y;
		let prevX = this.camera + this.headX;
		let prevY = this.worm.y;
		let hi = 0;
		const latest = (this.histHead - 1 + HIST) % HIST;
		for (let s = 1; s < n; s++) {
			let need = this.spacing;
			let guard = 0;
			while (need > .4 && hi < this.histCount && guard++ < 80) {
				const idx = (latest - hi + HIST) % HIST;
				const wx = this.histX[idx];
				const wy = this.histY[idx];
				const dx = wx - prevX;
				const dy = wy - prevY;
				const d = Math.hypot(dx, dy);
				if (d < .001) {
					hi++;
					continue;
				}
				if (d >= need) {
					const t = need / d;
					prevX += dx * t;
					prevY += dy * t;
					need = 0;
				} else {
					prevX = wx;
					prevY = wy;
					need -= d;
					hi++;
				}
			}
			this.segs[s].x = prevX - this.camera;
			this.segs[s].y = prevY;
		}
	}
	emit(x, y, count, hue, kick) {
		let left = this.reduce ? Math.min(4, count) : count;
		for (const p of this.particles) {
			if (left <= 0) break;
			if (p.alive) continue;
			const a = Math.random() * Math.PI * 2;
			const s = kick * (.25 + Math.random() * .75);
			p.alive = true;
			p.x = x + (Math.random() - .5) * 8;
			p.y = y + (Math.random() - .5) * 6;
			p.vx = Math.cos(a) * s * .4 - this.speed * .15;
			p.vy = Math.sin(a) * s * .35;
			p.life = .35 + Math.random() * .35;
			p.max = p.life;
			p.size = 2 + Math.random() * 3.2 * this.scale;
			p.hue = (hue + Math.random() * 50) % 360;
			p.grav = 40 + Math.random() * 80;
			left--;
		}
	}
	floater(x, y, text) {
		const f = this.floaters.find((item) => !item.alive) ?? this.floaters[0];
		f.alive = true;
		f.x = x;
		f.y = y;
		f.text = text;
		f.life = .7;
		f.max = .7;
	}
	updateParticles(dt) {
		for (const p of this.particles) {
			if (!p.alive) continue;
			p.life -= dt;
			if (p.life <= 0) {
				p.alive = false;
				continue;
			}
			p.vy += p.grav * dt;
			p.x += p.vx * dt;
			p.y += p.vy * dt;
		}
	}
	updateFloaters(dt) {
		for (const f of this.floaters) {
			if (!f.alive) continue;
			f.life -= dt;
			if (f.life <= 0) f.alive = false;
		}
	}
	bump(amount) {
		if (this.reduce) return;
		this.trauma = Math.min(1, this.trauma + amount);
	}
	pollPad() {
		const pads = navigator.getGamepads?.();
		if (!pads) return;
		let down = false;
		for (const pad of pads) {
			if (!pad) continue;
			const b = pad.buttons;
			if (b[0]?.pressed || b[1]?.pressed || b[12]?.pressed) down = true;
		}
		if (down && !this.padWas) {
			this.padJump = true;
			this.notePress();
		} else if (!down && this.padWas) {
			this.padJump = false;
			if (!this.held()) this.noteRelease();
		}
		this.padWas = down;
		this.padJump = down;
	}
	resize() {
		const rect = this.canvas.getBoundingClientRect();
		const w = Math.max(280, rect.width || window.innerWidth);
		const h = Math.max(280, rect.height || window.innerHeight);
		this.dpr = Math.min(2, window.devicePixelRatio || 1);
		this.canvas.width = Math.round(w * this.dpr);
		this.canvas.height = Math.round(h * this.dpr);
		this.layout(w, h);
	}
	layout(w, h) {
		this.width = w;
		this.height = h;
		this.scale = Math.max(.8, Math.min(1.4, Math.min(w, h) / 520));
		this.groundY = h * .78;
		this.headX = Math.max(72, Math.min(220, w * .2));
		this.radius = 22 * this.scale;
		this.hitR = this.radius * .52;
		this.spacing = this.radius * .78;
		this.segCount = Math.max(12, Math.min(18, Math.round(15 * this.scale)));
		const lead = Math.max(120, w - this.headX - 30);
		this.maxSpeed = Math.max(340, Math.min(760, lead / .78));
		this.baseSpeed = this.maxSpeed * .48;
		this.jumpH = Math.max(96, Math.min(210, Math.min(this.groundY * .42, h * .32)));
		this.jumpV = 4 * this.jumpH / AIR;
		this.grav = 8 * this.jumpH / (AIR * AIR);
		if (this.mode !== "play") {
			this.worm.y = this.groundY - this.radius;
			this.speed = this.baseSpeed;
		}
		if (this.histCount < 10) this.seedHistory();
	}
	syncHud() {
		const score = this.mode === "menu" ? this.best : this.score;
		this.hud.score.textContent = String(this.mode === "menu" ? 0 : score);
		this.hud.best.textContent = String(this.mode === "play" || this.mode === "pause" ? this.bestAtStart : this.best);
		this.hud.stars.textContent = String(this.mode === "play" || this.mode === "pause" || this.mode === "dead" ? this.stars : 0);
	}
	persist() {
		try {
			localStorage.setItem(SAVE_KEY, JSON.stringify({
				best: this.best,
				mute: this.sfx.muted,
				version: 1
			}));
		} catch {}
	}
	draw() {
		const ctx = this.ctx2d;
		if (!ctx) return;
		const sh = this.reduce ? 0 : this.trauma * this.trauma;
		const ox = (hash(Math.floor(this.time * 50)) - .5) * 18 * sh;
		const oy = (hash(Math.floor(this.time * 46) + 3) - .5) * 12 * sh;
		ctx.setTransform(this.dpr, 0, 0, this.dpr, ox * this.dpr, oy * this.dpr);
		drawWorld(ctx, {
			width: this.width,
			height: this.height,
			camera: this.camera,
			time: this.time,
			groundY: this.groundY,
			headX: this.headX,
			radius: this.radius,
			scale: this.scale,
			jumpH: this.jumpH,
			mode: this.mode,
			wormY: this.worm.y,
			wormVy: this.worm.vy,
			stretch: this.stretch,
			blink: this.blink,
			spin: this.spin,
			dead: this.mode === "dead",
			segs: this.segs,
			segCount: this.segCount,
			stars: this.starfield,
			obstacles: this.obstacles,
			pickups: this.pickups,
			particles: this.particles,
			floaters: this.floaters,
			flash: this.flash,
			speed: this.speed,
			maxSpeed: this.maxSpeed
		});
	}
};
function fromUi(e) {
	const t = e.target;
	return t instanceof Element && !!t.closest("[data-ui]");
}
function circleRect(cx, cy, r, rx, ry, rw, rh) {
	const nx = Math.max(rx, Math.min(cx, rx + rw));
	const ny = Math.max(ry, Math.min(cy, ry + rh));
	const dx = cx - nx;
	const dy = cy - ny;
	return dx * dx + dy * dy < r * r;
}
function makePts(kind, seed, w, h) {
	if (kind === "satellite") return [];
	const rnd = randMulberry(seed);
	if (kind === "crystal") return [
		{
			x: 0,
			y: -h
		},
		{
			x: w * .42,
			y: -h * .18
		},
		{
			x: w * .22,
			y: 0
		},
		{
			x: -w * .28,
			y: 0
		},
		{
			x: -w * .36,
			y: -h * (.28 + rnd() * .15)
		}
	];
	const n = 6 + Math.floor(rnd() * 3);
	const pts = [];
	for (let i = 0; i < n; i++) {
		const t = i / (n - 1);
		const ang = Math.PI - t * Math.PI;
		const rad = .82 + rnd() * .28;
		pts.push({
			x: Math.cos(ang) * (w / 2) * rad,
			y: -Math.sin(ang) * h * (.86 + rnd() * .18)
		});
	}
	return pts;
}
function RainbowRun() {
	const canvasRef = (0, import_react.useRef)(null);
	const stageRef = (0, import_react.useRef)(null);
	const scoreRef = (0, import_react.useRef)(null);
	const bestRef = (0, import_react.useRef)(null);
	const starsRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const [mode, setMode] = (0, import_react.useState)("menu");
	const [stats, setStats] = (0, import_react.useState)(null);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [run, setRun] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const stage = stageRef.current;
		const score = scoreRef.current;
		const best = bestRef.current;
		const stars = starsRef.current;
		if (!canvas || !stage || !score || !best || !stars) return;
		const engine = new RainbowEngine(canvas, {
			score,
			best,
			stars,
			stage
		}, (event) => {
			if (event.type === "mode") setMode(event.mode);
			else if (event.type === "start") setRun((n) => n + 1);
			else if (event.type === "over") setStats(event.stats);
			else setMuted(event.muted);
		});
		engineRef.current = engine;
		return () => {
			engine.destroy();
			engineRef.current = null;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: stageRef,
		className: "stage",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "safe-pad pointer-events-none absolute inset-0 flex flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-accent",
							children: "SCORE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: scoreRef,
							className: "score-num font-display text-4xl leading-none tabular-nums",
							children: "0"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 flex items-center gap-3 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Best ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								ref: bestRef,
								className: "font-semibold text-fg tabular-nums",
								children: "0"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
									className: "size-4 text-accent",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									ref: starsRef,
									className: "font-semibold text-fg tabular-nums",
									children: "0"
								})]
							})]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-auto flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"data-ui": "",
							className: "flex size-11 items-center justify-center rounded-full border border-border bg-surface/80 text-fg backdrop-blur-md",
							onClick: () => engineRef.current?.toggleMute(),
							"aria-label": muted ? "Unmute" : "Mute",
							children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
						}), mode === "play" || mode === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"data-ui": "",
							className: "flex size-11 items-center justify-center rounded-full border border-border bg-surface/80 text-fg backdrop-blur-md",
							onClick: () => engineRef.current?.togglePause(),
							"aria-label": mode === "pause" ? "Resume" : "Pause",
							children: mode === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" })
						}) : null]
					})]
				}), mode === "play" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hint-fade pointer-events-none mt-auto mb-4 text-center text-sm font-medium text-muted",
					children: "Tap or hold to jump higher"
				}, run) : null]
			}),
			mode === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-start justify-center safe-pad",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-in pointer-events-auto mt-16 w-full max-w-sm rounded-2xl border border-border bg-surface/90 p-5 text-center shadow-2xl backdrop-blur-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-accent",
							children: "ENDLESS SPACE HOP"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "logo-text font-display mt-2 text-4xl leading-none sm:text-5xl",
							children: "Rainbow Worm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: "Hop the space junk. A tap is a short hop. Hold for a high one."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"data-ui": "",
							className: "mt-5 h-12 w-full rounded-full bg-accent text-base font-semibold text-accent-ink",
							onClick: () => engineRef.current?.start(false),
							children: "Play"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-muted",
							children: "Space, tap, or ↑ · M mute · Esc pause"
						})
					]
				})
			}) : null,
			mode === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-start justify-center safe-pad",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-in pointer-events-auto mt-20 w-full max-w-sm rounded-2xl border border-border bg-surface/90 p-6 text-center backdrop-blur-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl",
							children: "Paused"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "The current keeps moving when you do."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"data-ui": "",
							className: "mt-5 h-12 w-full rounded-full bg-accent text-base font-semibold text-accent-ink",
							onClick: () => engineRef.current?.togglePause(),
							children: "Resume"
						})
					]
				})
			}) : null,
			mode === "dead" && stats ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-start justify-center safe-pad",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-in pointer-events-auto mt-20 w-full max-w-sm rounded-2xl border border-border bg-surface/90 p-6 text-center backdrop-blur-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-accent",
							children: stats.isNewBest ? "NEW BEST" : "SPLAT"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display mt-1 text-5xl tabular-nums leading-none",
							children: stats.score
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-3 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-border px-2 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "Distance"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-semibold tabular-nums",
										children: stats.distance
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-border px-2 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "Stars"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-semibold tabular-nums",
										children: stats.stars
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-border px-2 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "Close"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-semibold tabular-nums",
										children: stats.near
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"data-ui": "",
							className: "mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-accent text-base font-semibold text-accent-ink",
							onClick: () => engineRef.current?.restart(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Retry"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"data-ui": "",
							className: "mt-2 h-11 w-full rounded-full border border-border text-sm font-semibold text-fg",
							onClick: () => engineRef.current?.toMenu(),
							children: "Menu"
						})
					]
				})
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RainbowRun, {});
}
//#endregion
export { Home as component };
